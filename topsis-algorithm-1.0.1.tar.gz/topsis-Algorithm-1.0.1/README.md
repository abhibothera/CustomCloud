# TOPSIS-in-Python
 
Implementation of TOPSIS(Technique for Order of Preference by Similarity to Ideal Solution) in Python
Done For UCS633 (Data Analytics & Visualisation) by Pulkit Gupta (101703408)
